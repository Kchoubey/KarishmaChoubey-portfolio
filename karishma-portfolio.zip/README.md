# Karishma Choubey — Personal Portfolio

A responsive, dark-mode personal portfolio inspired by the provided Notion screenshots.

## Run locally
Open `index.html` in a browser.

## Customize
- Replace `profile.jpg` with a higher-resolution portrait if available.
- Update the LinkedIn URL in `index.html`.
- Replace `hello@example.com` with the preferred email address.
- Edit experience, product reviews, and about text directly in `index.html`.

No build tools or dependencies are required.
